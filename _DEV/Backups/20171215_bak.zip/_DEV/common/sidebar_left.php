<?php
echo "
<div class='3u'>
    <section id='sidebar1'>
        <header>
            <h2>Important Dates</h2>
        </header>
        <ul class='style3'>
            <li class='first'>
                <p class='date'>Aug <b>30</b></p>
                <p><a href='http://www.jbchockey.com/register.html' target='_blank'>Click here to register for the league</a></p>
            </li>
            <li>
                <p class='date'>Sep <b>13</b></p>
                <p>Pre-Season Scramble Games Begin</p>
            </li>
            <li>
                <p class='date'>Oct <b>04</b></p>
                <p>2017-2018 Regular Season Begins</p>
            </li>
        </ul>
    </section>
</div>
"
?>