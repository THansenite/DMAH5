<?php
echo "
    <div id='header'>
        <div class='container'> 
            
            <!-- Logo -->
            <div id='logo'>
                <h1><a href='#'>Des Moines Adult Hockey</a></h1>
                <span>Your source for JBC League info</span>
            </div>
            
            <!-- Nav -->
            <nav id='nav'>
                <ul>
                    <!-- <li class=active'><a href='index.html'>Homepage</a></li> -->
                    <li><a href='index.php'>Home</a></li>
                    <li><a href='schedule.php'>Schedule</a></li>
                    <li><a href='standings.php'>Standings</a></li>
                    <li><a href='stats.php'>Player Stats</a></li>
                    <li><a href='images/JBCHockeyCharterAndRules1_2.pdf' target='_blank'>League Rules</a></li>
                </ul>
            </nav>
        </div>
    </div>";
?>
