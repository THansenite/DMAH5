<?php
    /* Info to hook up to a database.
    * This is imported by other pages to set up the database. This
    * page should never be called directly.
    */
    $username = "broomball_admin";
    $password = "aiLae7ph";
    $database = "broomball";
    $server   = "p3plcpnl0972.prod.phx3.secureserver.net";
 
    // This connects to the database. It is necessary before
    // doing any database commands.
    //mysql_connect($server,$dbusername,$dbpassword) or die ("Unable to connect to database");
    //$connection = mysqli_connect($server,$username,$password,$database);
    $connection = mysqli_connect($server, $username, $password, $database) or die ("Connection failed");

    
    // This is a bad way to show an error!
    //mysql_select_db($database) or die( "Unable to select database");

  ?>
